<?php

/**
 * 消息节点
 * @author auto create
 */
class RoamingMessageItem
{
	
	/** 
	 * 节点类型
	 **/
	public $type;
	
	/** 
	 * 值
	 **/
	public $value;	
}
?>